import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import tempfile

# 예시 데이터 생성
timestamps = pd.date_range("2024-08-27", periods=100, freq="T")
runner_a = np.cumsum(np.random.randint(1, 10, size=len(timestamps)))
runner_b = np.cumsum(np.random.randint(1, 10, size=len(timestamps)))
runner_c = np.cumsum(np.random.randint(1, 10, size=len(timestamps)))

data = pd.DataFrame({
    "timestamp": timestamps,
    "Runner A": runner_a,
    "Runner B": runner_b,
    "Runner C": runner_c
})

def animate_race(data):
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.set_xlim(0, len(data))
    
    # 숫자 열만 고려하여 y축 최대값 설정
    numeric_max = data.drop(columns="timestamp").max().max()
    ax.set_ylim(0, numeric_max)
    
    line_a, = ax.plot([], [], lw=4, label='Runner A', color='blue')
    line_b, = ax.plot([], [], lw=4, label='Runner B', color='red')
    line_c, = ax.plot([], [], lw=4, label='Runner C', color='green')
    ax.legend()

    def update(num):
        line_a.set_data(range(num), data['Runner A'][:num])
        line_b.set_data(range(num), data['Runner B'][:num])
        line_c.set_data(range(num), data['Runner C'][:num])
        ax.set_title(f"Time: {data['timestamp'].iloc[num]}")
        return line_a, line_b, line_c

    ani = animation.FuncAnimation(fig, update, frames=len(data), interval=100, blit=True)
    
    # 임시 파일에 애니메이션을 저장
    with tempfile.NamedTemporaryFile(suffix=".gif", delete=False) as tmpfile:
        ani.save(tmpfile.name, writer='pillow')
        return tmpfile.name

# Streamlit 앱
st.title("달리기 시합 애니메이션")

# 애니메이션 생성 및 Streamlit에 표시
gif_path = animate_race(data)
st.image(gif_path)
