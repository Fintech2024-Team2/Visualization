import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import streamlit as st

# 데이터 로드
df = pd.read_csv('/Users/chaewon/Desktop/snukdt/시각화웹개발/project/Visualization/labeled_data_final.csv')

# 조별로 인물들을 그룹핑
group_mapping = df.set_index('class')['조'].to_dict()

def create_heatmap(df):
    # Ensure 'count' is correct
    df['count'] = df.groupby('filename')['filename'].transform('size')
    interaction_matrix = pd.crosstab(df['class'], df['class'], df['count'], aggfunc='sum').fillna(0)

    # Sorting interaction matrix by groups
    sorted_index = sorted(interaction_matrix.index, key=lambda x: (group_mapping.get(x, 'ZZZ'), x))
    interaction_matrix = interaction_matrix.reindex(index=sorted_index, columns=sorted_index)

    # Plotting the heatmap
    plt.figure(figsize=(15, 12))
    sns.heatmap(interaction_matrix, cmap="YlGnBu", annot=True, fmt="g", linewidths=.5)
    plt.title('인물 간 만남 횟수 히트맵')
    plt.show()

def show():
    st.title("9기의 워크샵 인물 관계 히트맵 시각화")

    # 히트맵 생성
    create_heatmap(df)

if __name__ == "__main__":
    show()
