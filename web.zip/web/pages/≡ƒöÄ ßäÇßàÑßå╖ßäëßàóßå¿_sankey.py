import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import tempfile

# CSV 파일을 읽어오는 부분
df = pd.read_csv("labeled_data.csv")

# 시간 데이터를 datetime 형식으로 변환
df['timestamp'] = pd.to_datetime(df['timestamp'])

# Streamlit 사이드바에서 인물 선택 UI 추가
nodes = df['class'].unique()
selected_person = st.sidebar.selectbox("인물을 선택하세요", nodes)

# 선택된 인물과 다른 인물들이 얼마나 자주 만났는지 계산
result = []

for timestamp, group in df.groupby('timestamp'):
    if selected_person in group['class'].values:
        relation_counts = {}
        for person in group['class'].unique():
            if person != selected_person:
                count = group[(group['class'] == selected_person) & (group['filename'].isin(group[group['class'] == person]['filename']))].shape[0]
                relation_counts[person] = relation_counts.get(person, 0) + count

        # 결과 저장
        for person, count in relation_counts.items():
            result.append({"timestamp": timestamp, "person": person, "count": count})

# DataFrame으로 변환
result_df = pd.DataFrame(result)

# 누적 합 계산 (시간에 따른 누적 만남 횟수)
result_df = result_df.groupby(["timestamp", "person"]).sum().groupby(level=1).cumsum().reset_index()

# 각 시간대별로 상위 5명만 필터링
top_5_df = result_df.groupby("timestamp").apply(lambda x: x.nlargest(5, 'count')).reset_index(drop=True)

# 애니메이션 생성 함수
def animate_race(data):
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # x축 범위는 데이터 길이에 따라 설정
    ax.set_xlim(0, len(data['timestamp'].unique()))

    # y축 범위는 가장 많이 만난 횟수에 따라 설정
    numeric_max = data['count'].max()
    ax.set_ylim(0, numeric_max)

    # 라인 초기화
    lines = {person: ax.plot([], [], lw=4, label=person)[0] for person in data['person'].unique()}
    ax.legend()

    def update(frame):
        current_time = data['timestamp'].unique()[frame]
        current_data = data[data['timestamp'] <= current_time]
        for person, line in lines.items():
            if person in current_data['person'].unique():
                person_data = current_data[current_data['person'] == person]
                line.set_data(range(len(person_data)), person_data['count'])
        ax.set_title(f"Time: {current_time}")
        return list(lines.values())

    ani = animation.FuncAnimation(fig, update, frames=len(data['timestamp'].unique()), interval=100, blit=True)

    # 애니메이션을 GIF로 저장
    with tempfile.NamedTemporaryFile(suffix=".gif", delete=False) as tmpfile:
        ani.save(tmpfile.name, writer='pillow')
        return tmpfile.name

# Streamlit 앱
st.title(f"{selected_person}의 상위 5명과의 만남 애니메이션")

# 애니메이션 생성 및 Streamlit에 표시
gif_path = animate_race(top_5_df)
st.image(gif_path)
